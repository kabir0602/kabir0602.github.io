var responses = [];

document.getElementById("buttonSubmit").addEventListener("click",function(e){
    e.preventDefault();
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var email = document.getElementById("email").value;
    var meal = document.getElementById("meal").value;
    if(firstName.length == 0 || lastName.length == 0 || email.length == 0 || meal.length == 0){
        alert("Please complete the form !!");
    }
    else if(/[A-Za-z]/.test(firstName) == false){
        alert("Invalid First Name !!");
    }
    else if(/[A-Za-z]/.test(lastName) == false){
        alert("Invalid Last Name !!");
    }
    else{
        let response = {
            "firstName":firstName,
            "lastName":lastName,
            "email":email,
            "meal":meal
        };
        responses.push(response);
        alert("Thank you !! \nYour reponse has been recorded !!");
        console.log(responses);
    }
});