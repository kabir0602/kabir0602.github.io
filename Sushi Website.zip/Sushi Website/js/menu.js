
var menu = ["Home", "Reviews", "Contact us", "About us"];

menu.forEach((item)=>{
  if(localStorage.getItem("stored") == item){
    document.getElementById(item).style.backgroundColor = "rgb(253, 144, 1)";
    document.getElementById(item).style.color = "white"
  }
});